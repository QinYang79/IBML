
# You should first obtain the raw data and put them into the folders of AudioWAV and VideoFlash.
# Modify the corresponding parameter: root_dir.
python3 video_preprocessing.py

