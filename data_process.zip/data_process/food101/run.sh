

# https://github.com/QingyangZhang/QMF
# https://www.kaggle.com/datasets/gianmarco96/upmcfood101
# download the data from the above link and put them into the folder of images.
