import os
import moviepy.editor as mp

def extract_audio(videos_file_path):
    my_clip = mp.VideoFileClip(videos_file_path)
    return my_clip

root_dir = '/home/qinyang/projects/Cross-modal/MutilmodalFusion/OGM_GE/data/AVE_Dataset'
all_videos = f'{root_dir}/Annotations.txt'
all_audio_dir = f'{root_dir}/Audios'
mp4_path = f'{root_dir}/Mp4s'
if not os.path.exists(all_audio_dir):
    os.makedirs(all_audio_dir)

# train set processing
with open(all_videos, 'r') as f:
    files = f.readlines()

for i, item in enumerate(files[1:]):
    if i % 500 == 0:
        print('*******************************************')
        print('{}/{}'.format(i, len(files)))
        print('*******************************************')
    item = item.split('&')
    mp4_filename = os.path.join(mp4_filename, item[1] + '.mp4')
    wav_filename = os.path.join(all_audio_dir, item[1]+'.wav')
    if os.path.exists(wav_filename):
        pass
    else:
        my_clip = extract_audio(mp4_filename)
        my_clip.audio.write_audiofile(wav_filename)
