# !/usr/bin/env python3

# @inproceedings{TianECCV2018,
# 	 title={Audio-Visual Event Localization in Unconstrained Videos},
#      author={Tian, Yapeng and Shi, Jing and Li, Bochen and Duan, Zhiyao and Xu, Chenliang},
# 	 editor="Ferrari, Vittorio and Hebert, Martial and Sminchisescu, Cristian and Weiss, Yair",
# 	 booktitle="Computer Vision -- ECCV 2018",
# 	 year="2018",
# 	 publisher="Springer",
# }

# You should first obtain the raw data and put them into the folders of Audios and Mp4s.
# Modify the corresponding parameter: root_dir.
python3  m_2_w.py

# Modift the corresponding parameter: root_dir.
python3 v_p.py

